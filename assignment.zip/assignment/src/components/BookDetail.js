//Display the details of selected book

import React from "react";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";

const BookDetail = ({ selectedBook }) => {
  if (!selectedBook) {
    return <Redirect to="/" />;
  }

  return (
    <div className="card container" style={{ width: "18rem" }}>
      <img
        src={selectedBook.volumeInfo.imageLinks.smallThumbnail}
        className="card-img-top"
        alt="book_image"
      />
      <div className="card-body">
        <h5 className="card-title">{selectedBook.volumeInfo.title}</h5>
        <p className="card-text">
          {selectedBook.volumeInfo.subtitle || `subtitle...`}
        </p>
      </div>
    </div>
  );
};

const mapStateToProps = ({ selectedBookReducer }) => {
  return {
    selectedBook: selectedBookReducer,
  };
};

export default connect(mapStateToProps, {})(BookDetail);
