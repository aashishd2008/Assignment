//Fetching the list of books and passing each book as a prop to Book Component

import React from "react";
import { connect } from "react-redux";
import { fetchBooks } from "../actions";
import Book from "./Book";

class BookList extends React.Component {
  renderedList = () => {
    return this.props.books.map((book) => {
      return <Book key={book.id} book={book} />;
    });
  };
  componentDidMount() {
    this.props.fetchBooks();
  }
  render() {
    return <div>{this.renderedList()}</div>;
  }
}

const mapStateToProps = ({ bookReducer }) => {
  return {
    books: bookReducer,
  };
};

export default connect(mapStateToProps, { fetchBooks })(BookList);
