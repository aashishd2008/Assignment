// Display the list of books

import React from "react";
import { connect } from "react-redux";
import { selectedBook } from "../actions";
import { Link } from "react-router-dom";

const Book = (props) => {
  return (
    <div>
      <ul className="list-group">
        <li
          className="list-group-item"
          onClick={() => {
            props.selectedBook(props.book);
          }}
        >
          <Link to="/detail">{props.book.volumeInfo.title}</Link>
        </li>
      </ul>
    </div>
  );
};

export default connect(null, { selectedBook })(Book);
